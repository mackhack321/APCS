public class StarsRunner
{
   public static void main(String args[])
   {
       StarsAndStripes a = new StarsAndStripes();
       a.printTwentyStars();
       a.printTwoBlankLines();
       a.printABigBox();
       a.printTwoBlankLines();
       a.printASmallBox();
       a.printTwoBlankLines();
       a.printTwentyDashes();    
   }
}